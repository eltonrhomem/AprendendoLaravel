<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Escola;

class EscolaController extends Controller
{
    public function listar()
    {
        $escola = Escola::all();
        return view('escolas.listar',compact('escola'));
       // return view('escolas.listar');
    }

    public function formCadastrar()
    {
        return view('escolas.cadastrar');
    }

    public function cadastrar(Request $request)
    {
        $escola = new Escola();
        $escola->cdtipesc = $request->cdtipesc;
        $escola->cdescola = $request->cdescola;
        $escola->nmescola = $request->nmescola;
        $escola ->save();

        return redirect()->to('/escolas/listar');
    }
}
