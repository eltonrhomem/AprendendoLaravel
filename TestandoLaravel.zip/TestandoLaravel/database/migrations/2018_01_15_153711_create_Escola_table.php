<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEscolaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('eicescol', function (Blueprint $table) {
            $table->smallInteger('cdtipesc')->unsigned();
            $table->smallInteger('cdescola')->unsigned();
            $table->string('nmescola');
            $table->timestamps();        
            //$table->primary('cdescola');
            $table->primary(['cdtipesc','cdescola']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('eicescol');
    }
}
