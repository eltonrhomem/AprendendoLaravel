<html>

    <head></head>
    <body>
        <h1> Listar Escolas</h1>
        <a href = "/escolas/form-cadastrar"> Nova Escola </a>
            <table>
                <thead>
                    <tr>
                        <th>cdtipesc</th>
                        <th>cdescola</th>
                        <th>nmescola</th>

                    </tr>

                </thead>

                <tbody>
                    @foreach ($escola as $escolas)
                        <tr>
                            <td>{{$escolas->cdtipesc}}</td>
                            <td>{{$escolas->cdescola}}</td>
                            <td>{{$escolas->nmescola}}</td>
                        </tr>
                        
                    @endforeach   
                </tbody>
                    
            </table>
    <body>

</html>