<html>

    <head></head>
    <body>
        <h1> Cadastrar Escolas</h1>
        <a href = "/escolas/listar"> Listar escolas </a>
    <form method ="post" action = "/escolas/cadastrar">
        <?php echo csrf_field(); ?>

       Cdtipesc: <input type = "text" name = "cdtipesc"><br>
       Cdescola: <input type = "text" name = "cdescola"><br>
       NmEscola: <input type = "text" name = "nmescola"><br>
       <br><br>
       <button type = "submit"> Enviar </button>
    </form>
    
    <body>

</html>