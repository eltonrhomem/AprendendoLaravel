<html>

    <head></head>
    <body>
        <h1> Listar Escolas</h1>
        <a href = "/escolas/form-cadastrar"> Nova Escola </a>
            <table>
                <thead>
                    <tr>
                        <th>cdtipesc</th>
                        <th>cdescola</th>
                        <th>nmescola</th>

                    </tr>

                </thead>

                <tbody>
                    <?php $__currentLoopData = $escola; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escolas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($escolas->cdtipesc); ?></td>
                            <td><?php echo e($escolas->cdescola); ?></td>
                            <td><?php echo e($escolas->nmescola); ?></td>
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                </tbody>
                    
            </table>
    <body>

</html>